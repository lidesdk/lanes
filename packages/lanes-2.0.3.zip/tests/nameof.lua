lanes = require "lanes".configure()

print( lanes.nameof( {}))
print( lanes.nameof( string.sub))
print( lanes.nameof( print))
